<?php
$string['pluginname'] = 'Shell Plugin';
$string['shell:use'] = 'Use shell';
?>
