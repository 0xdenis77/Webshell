<?php
$plugin->component = 'local_shell';
$plugin->version = 2026062800;
$plugin->requires = 2018051700;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0.0';
?>
